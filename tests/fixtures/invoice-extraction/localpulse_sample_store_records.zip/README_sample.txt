LOCALPULSE AI - SYNTHETIC KIRANA SAMPLE

Upload sample_kirana_invoice.png to test photo OCR / Gemini Vision, if the upload feature is implemented.
Compare output against sample_extracted_invoice.json.
Use sample_store_inventory.csv for CSV import testing, only after checking expected column mappings.
All data is fictional. The GST percentage is illustrative and not a statement of applicable tax rates.
The composite image is a visual demonstration, not an actual working ZIP.
